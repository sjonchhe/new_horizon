<?php
$uname=$_POST['uname'];
$upassword=$_POST['upassword'];
$uemail=$_POST['uemail'];
//extract($_POST);
include_once('../admin/class/classuser.php');
$user=new User();
$user->userRegister($uname,$upassword,$uemail);

?>
