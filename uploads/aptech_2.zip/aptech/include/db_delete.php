<?php
$delname=$_POST['delname'];
//extract($_POST);
include_once('../admin/class/classuser.php');
$user=new User();
$user->userDelete($delname);

?>
