<?php
extract($_POST);
include_once('../admin/class/classuser.php');
$user=new User();
$user->userUpdate($uname,$upassword,$uemail);
?>
