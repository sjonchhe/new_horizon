<?php


define('DB_SERVER', 'localhost');
define('DB_USERNAME','root');
define('DB_PASSWORD','');
define('DB_DATABASE','news');

Class dbConnect
{
    public $db;
      public function __construct()
      {
        $this->db= new mysqli(DB_SERVER, DB_USERNAME,DB_PASSWORD,DB_DATABASE);

        if(mysqli_connect_errno())
        {
          echo "Error:Could not connect to database.";
          exit;
        }
      }


    public function dbConnection()
    {
      $this->con=new mysqli("localhost","root","","news");
      if(!$this->con)
      {
        echo"Opps!Error in database connection";
      }
      else {
        echo"Database successfully connected";
      }

    }

    public function createTable()
    {
      $sql="CREATE TABLE `userinfo1`
      (
        'uid' INT(11) PRIMARY KEY,
        `uname` VARCHAR(40) DEFAULT NULL,
        `upassword` VARCHAR(40) DEFAULT NULL,
        `uemail` VARCHAR(40) DEFAULT NULL,
        `utype` TINYINT(4)DEFAULT NULL,
        `ustatus` TINYINT(1) DEFAULT NULL
      )";

      $qry=mysqli_query($this->con,$sql) or die ("Something error!");

    }



}
?>
