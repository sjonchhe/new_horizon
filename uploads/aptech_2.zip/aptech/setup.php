<?php
    require_once('include/db_config.php');
  //  require_once('include/db_insert.php');
    $obj=new dbConnect();
    $obj->dbConnection();
    //$obj->dbInsert('$uid','$uname','$upword','$uemail','$utype','$ustatus');

    //$ojb=new dbIns();
    //$ojb->dbInsert('$uid','$uname','$upword','$uemail','$utype','$ustatus');
    $obj->createTable();



?>
