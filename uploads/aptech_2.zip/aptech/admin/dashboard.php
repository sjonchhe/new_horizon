<?php include_once('inc_session.php'); ?>
<!--<?php
  echo "<h2>Im dashboard</h2>";

/*  if($_SERVER['REQUEST_METHOD']=='POST')
  {

    extract($_POST);
    include_once('class/classuser.php');
    $user=new User();
  $user->userRegister($uname,$upassword,$uemail);
  //  $user->userLogin($uname,$upassword);
}*/
?>-->
<!doctype html>
<html>
<head>
  <title>Dashboard</title>

  <meta charset="utf-8"/>
  <meta name="author" content="Sandesh Jonchhe">
  <meta name="keyword" content="dashboard,myadmin">
  <meta name="description" content="Dashboard by Sandesh Jonchhe">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<?php include('inc_linkscript.php'); ?>
</head>
<body>
<div class="container-fluid" style="height:auto;background:#C0C0C0;box-shadow:0px 3px 10px black;">
  <div class="row">
      <div class="col-md-12" style="padding:20px;background:#9A9A9A;">
          <h2>Welcome Admin!</h2>
          <?php include('inc_header.php');?>
      </div>
  </div>
    <div class="row">
        <div class="col-md-3 lead" style="height:800px;background:#8E8E8E;">
          Menu
          <?php include('inc_menu.php'); ?>
          </div>



        <div class="col-md-9" style="height:auto;">

            <div class="col-md-5 text-primary lead" style=" height:400px;margin:10px;padding:30px;">
                <kbd>User registration</kbd><br>
                    <table class="table table-condensed">
                       <form action="../include/db_insert.php" method="POST">
                         <tr><td colspan="2">USER REGISTER</td></tr>
                         <tr><td>Uname :</td><td><input type="text" placeholder="username" name="uname"></td></tr>
                         <tr><td>Upword :</td><td><input type="password" placeholder="password" name="upassword"></td></tr>
                         <tr><td>uemail :</td><td><input type="email" placeholder="email" name="uemail"></td></tr>


                         <tr><td colspan="2"><input type="submit" value="Register" class="btn-primary"></td></tr>
                       </form>
                   </table>
            </div>
            <div class="col-md-5 lead"table-responsive" style="height:400px;margin:10px;padding:30px;">
                <kbd>User Update</kbd><br>
                <table class="table table-condensed">
                   <form action="../include/db_update.php" method="POST">
                     <tr><td colspan="2">USER UPDATE</td></tr>
                     <tr><td>Uname :</td><td><input type="text" placeholder="New username" name="newuname"></td></tr>
                     <tr><td>Upword :</td><td><input type="password" placeholder="New password" name="newupassword"></td></tr>
                     <tr><td>uemail :</td><td><input type="email" placeholder="New email" name="newuemail"></td></tr>


                     <tr><td colspan="2"><input type="submit" value="Update" class="btn-info"></td></tr>
                   </form>
               </table>
            </div>

            <div class="col-md-5 lead" style="height:400px;margin:10px;padding:30px;">
                <kbd>User Delete</kbd>  <br>
                <table class="table table-condensed">
                   <form action="../include/db_delete.php" method="POST">
                     <tr><td >USER DELETION</td></tr>
                     <tr><td >Enter the username of the person you want to delete</td></tr>
                     <tr><td><input type="text" placeholder="username" name="delname"></td></tr>

                     <tr><td ><input type="submit" value="Delete" class="btn-danger"></td></tr>
                   </form>
               </table>
            </div>
          </div>






    <div class="row">
        <div class="col-md-12 " style="padding:20px;">
          <?php include('inc_footer.php')?>
          </div>

    </div>
</div>
</body>
</html>
