<?php include_once('inc_session.php'); ?>

<?php
  include_once('class/classuser.php');
/*  if($_SERVER['REQUEST_METHOD']=='POST')
  {

    extract($_POST);
    include_once('class/classuser.php');
    $user=new User();
  $user->userRegister($uname,$upassword,$uemail);
  //  $user->userLogin($uname,$upassword);
}*/
?>-->
<!doctype html>
<html>
<head>
  <title>Dashboard</title>

  <meta charset="utf-8"/>
  <meta name="author" content="Sandesh Jonchhe">
  <meta name="keyword" content="dashboard,myadmin">
  <meta name="description" content="Dashboard by Sandesh Jonchhe">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<?php include('inc_linkscript.php'); ?>
</head>
<body>
<div class="container-fluid" style="height:auto;background:#C0C0C0;box-shadow:0px 3px 10px black;">
  <div class="row">
      <div class="col-md-12" style="padding:20px;background:#9A9A9A;">
          <h2>Welcome Admin!</h2>
          <?php include('inc_header.php');?>
      </div>
  </div>
    <div class="row">
        <div class="col-md-3 lead" style="height:800px;background:#8E8E8E;">
          Menu
          <?php include('inc_menu.php'); ?>
          </div>



        <div class="col-md-9" style="height:auto; padding:20px;">
            <h1>  MANAGE USER WILL BE HERE!</h1>

            <table class="table table-hover">
    <thead>
    <tr><th>Add User</th></tr>
      <tr>
        <th>USER ID</th>
        <th>USER NAME</th>
        <th>EMAIL</th>
        <th>STATUS</th>
        <th>FUNCTIONS</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $user=new User();
        $user->getAllUsers();
      ?>
        </tbody>
  </table>

</div>
      <div class="row">
          <div class="col-md-12 " style="padding:20px;">

            </div>

      </div>



        </div>






    <div class="row">
        <div class="col-md-12 " style="padding:20px;">

          </div>

    </div>
</div>
</body>
</html>
