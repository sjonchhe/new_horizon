<link href="../css/bootstrap.min.css" type="text/css" rel="stylesheet">
<link href="../css/style.css" type="text/css" rel="stylesheet">

<script src="../js/bootstrap.min.js">
</script>
<script src="../jquery/jquery-3.2.0.min.js">
</script>
