<?php
session_start();
if(!$_SESSION['login'])
{
  header ('location:user_log.php');
}

?>
