<?php
  session_start();
  if($_SERVER['REQUEST_METHOD']=='POST')
  {
    /*$uname=$_POST['uname'];
    $upassword=$_POST['upassword'];
    $uemail=$_POST['uemail'];*/
//OR CAN BE PULLED BY USING A SINGLE EXTRACT COMMAND WHICH CREATES THE SAME VARIABLE NAME AS THE NAME IN THE INPUT
    extract($_POST);
    include_once('class/classuser.php');
    $user=new User();
    $user->userLogin($uname,$upassword);
    }


 ?>
<html>
<head>
  <title>Practice</title>
  <link type="text/css" rel="stylesheet" href="../css/style.css">
</head>
<body>

<table>
  <form action="" method="POST">
    <tr><td colspan="2">USER LOGIN </td></tr>
    <tr><td>Uname :</td><td><input type="text" placeholder="username or useremail" name="uname"></td></tr>
    <tr><td>Upword :</td><td><input type="password" placeholder="password" name="upassword"></td></tr>


    <tr><td colspan="2"><input type="submit" value="Login" class="button"></td></tr>
</table>
</body>
</html>
