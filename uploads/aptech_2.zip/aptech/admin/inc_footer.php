<center>
&copy <?php echo date('Y');?>, All right reserved
</center>
