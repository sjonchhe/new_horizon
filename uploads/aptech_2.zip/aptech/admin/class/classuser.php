<?php
include('../include/db_config.php');

  class User extends dbConnect{
    public function userRegister($uname,$upassword,$uemail)
    {
        $sql1="INSERT INTO userinfo SET uname= '$uname',upassword ='$upassword', uemail='$uemail', utype='2',ustatus='0'";
        $result=mysqli_query($this->db,$sql1) or die(mysqli_connect_errno()."data cannot be inserted");
        if($result)
        {
          //echo "data inserted";

          header('Location: http://www.aptech.com/admin/dashboard.php');

        }
    }
    public function userLogin($uname,$upassword)

    {
      $sql2="SELECT uid from userinfo WHERE uemail='$uname' or uname='$uname' and upassword='$upassword'";
      $result=mysqli_query($this->db,$sql2);
      $user_data=mysqli_fetch_array($result);
      $count_row=$result->num_rows;

      if($count_row==1)
      {
        header('Location: dashboard.php');
        $_SESSION['login']=true;
        $_SESSION['uid']=$user_data['uid'];
        return true;

          header('Location: dashboard.php');

      }
      else{
        return false;
      }
    }

    public function userUpdate($uname,$upassword,$uemail)
    {
      $update="UPDATE userinfo SET uname='$newuname',upassword='$newupassword',uemail='$newuemail' WHERE uname='$uname',upassword='$upassword',uemail='$uemail'";
      $result1=mysqli_query($this->db,$update);
      $user_data=mysqli_fetch_array($result1);
      $count_row=$result1->num_rows;

      if($count_row==1)
      {
        header('Location: ../dashboard.php');

      }
      else{
        return false;
      }
    }

    public function userDelete($delname)
    {
      $delete="DELETE FROM userinfo WHERE uname='$delname'";
      $result3=mysqli_query($this->db,$delete);
      if($result3)
      {
        echo 'Successfully deleted';

      }
      else {
        echo 'Error in deletion!';
      }
    }
    Public function getAllUsers()
    {
        $sql3="SELECT * FROM userinfo ORDER BY uid DESC LIMIT 0,30"  ;
        $result=mysqli_query($this->db,$sql3);
        //$user_data=mysqli_fetch_array($result);
        //$count_row=$result->num_rows;

        while($row=mysqli_fetch_array($result))
        {
            echo "
            <tr>
              <td>".$row['uid']."</td>
              <td>".$row['uname']."</td>
              <td>".$row['uemail']."</td>
              <td>".$row['ustatus']."</td>
              <td>EDIT | DELETE</td>
            </tr>

            ";
        }

      }
      public function userCount()
      {
        $sql4="SELECT * from userinfo";
        $result=mysqli_query($this->db,$sql4);
        $user_data=mysqli_fetch_array($result);
        $count_row=$result->num_rows;
        echo "<span class='badge'>".$count_row."</span>";
      }
  }

?>
