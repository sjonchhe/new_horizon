<div class='navigation'>
    <ul>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li><a href="manageuser.php">User</a></li>
        <li>Article</li>
          <li>Gallery</li>

              <li></li>

      </ul>
</div>
